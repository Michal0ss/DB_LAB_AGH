# Zrzut danych

Ten katalog zawiera przygotowany eksport kolekcji MongoDB w formacie JSON Lines, podobnym do wyniku `mongoexport`.

Kolekcje:

- `clients`
- `trainers`
- `classes`
- `memberships`
- `reservations`
- `reviews`
- `classes_embedded`

Przykładowe polecenie eksportu po uruchomieniu bazy:

```bash
mongoexport --db gym_modeling --collection clients --out export_silownia_json/clients.json
```

